package frames;

public class GELauncher {

	public static void main(String[] args) {
		GEMainFrame frame = GEMainFrame.getInstance();
		frame.init();
	}

}
